# Deployment Steps

Step-by-step from your laptop to a live, password-protected URL. Should take 60-90 minutes total once you sit down with it.

## Phase 1: Local setup (15 min)

**1. Create the repo locally.** Since you already have a GitHub setup, just:

```bash
cd ~/ops-projects  # or wherever you keep things
mkdir dol-5500-lookup
cd dol-5500-lookup
```

Then unzip the bundle I gave you into this folder. You should have:

```
dol-5500-lookup/
├── .gitignore
├── .streamlit/
│   ├── config.toml
│   └── secrets.toml.example
├── README.md
├── app.py
├── data/.gitkeep
├── requirements.txt
└── src/
    ├── __init__.py
    └── matcher.py
```

**2. Set up Python locally.**

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

**3. Create your local secrets file.**

```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Edit `.streamlit/secrets.toml` and change `REPLACE_ME_WITH_A_REAL_PASSWORD` to whatever password you want. This file is gitignored — it will not be committed.

## Phase 2: Plug in your v4 logic (60 min)

This is the substantive work. Open `src/matcher.py` and look for the two **PASTE ZONE** sections:

**Zone 1: `load_dol_data()`** — paste the data-loading and join logic from your Colab notebook. The function should return a single dataframe ready to be searched, with the columns named in the docstring.

**Zone 2: `match()`** — paste the scoring/matching logic. For each row in the dataframe, compute a similarity score against `canonical_query`, sort descending, return the top `top_n` as `MatchResult` objects.

**Where to put your DOL CSV files:** drop them into `data/`. The `.gitignore` keeps them out of the repo. You'll need them locally to run the app, and you'll need to figure out how to handle them in Streamlit Cloud (see Phase 4 below).

**Test locally:**

```bash
streamlit run app.py
```

A browser tab opens at `http://localhost:8501`. Type the password, then type an employer name. If matches come back, you're done with this phase.

## Phase 3: Push to GitHub (10 min)

```bash
git init
git add .
git status   # double-check no data files or secrets.toml are staged
git commit -m "Initial scaffold for DOL 5500 recordkeeper lookup tool"

# Create a private repo on github.com first, then:
git remote add origin git@github.com:YOUR_USERNAME/dol-5500-lookup.git
git branch -M main
git push -u origin main
```

**Double-check before pushing:** open the repo on GitHub. You should NOT see `data/*.csv` or `.streamlit/secrets.toml`. If you do, stop and fix the .gitignore before going further.

## Phase 4: Deploy to Streamlit Cloud (15-30 min)

**1.** Go to https://share.streamlit.io and sign in with GitHub.

**2.** Click "New app." Select your `dol-5500-lookup` repo, branch `main`, main file `app.py`. Pick a URL slug (e.g. `pensionbee-5500-lookup`).

**3.** Before clicking Deploy, click "Advanced settings" → "Secrets" and paste the contents of your local `.streamlit/secrets.toml`:

```toml
app_password = "your-real-password-here"
```

**4.** Click Deploy. The first build takes 3-5 minutes.

**5. Handle the data problem.** Streamlit Cloud doesn't have your DOL CSVs. You have two options:

- **A. Commit a small sample.** If the matching reference data is under ~50MB total, you can commit it into a `data/sample/` subdirectory (remove that line from `.gitignore`). Easiest path but exposes the data in the repo.
- **B. Use Streamlit Cloud's file storage.** Streamlit lets you mount data via secrets or upload directly. Slightly more setup; better if data is sensitive.

For Fortune 1000 matching specifically (public DOL data), option A is probably fine. Make the call based on what's in the data.

## Phase 5: Notify your VP and share (10 min)

Once the deployed URL works end-to-end:

**Slack message to your VP:**

> "FYI — I productionized the 5500 matcher we discussed earlier as a small internal tool. It runs against public DOL Form 5500 data, hosted on Streamlit Cloud, password-gated. Anything I should think about before I share the URL internally? Happy to walk through it."

This is the senior-level move. You're not asking permission — you're giving notice and inviting concerns, which signals you thought about the question before shipping.

**Then send the URL to one stakeholder.** Probably the Head of Product who received your original decision memo. Frame:

> "Quick follow-up to the 5500 recordkeeper memo from [DATE]. I built a simple lookup tool that uses the v4 matching logic on the latest DOL data. Type an employer name, see the recordkeeper. URL: [link], password: [share separately]. Curious whether this is useful in its current form, or what would make it more useful."

## Phase 6: Track adoption (ongoing)

For your July comp conversation, the comp-relevant question is "who used this?" So track it:

- Note in a doc each time someone uses the tool, who, for what.
- After 4-6 weeks, count: number of unique users, lookups performed, time saved per lookup (estimate).
- One sentence by July: "Built and deployed an internal 5500 lookup tool used by [N] colleagues across [teams], collapsing manual recordkeeper research from ~10 minutes to seconds per lookup."

## What's NOT in this version (intentionally)

- Bulk lookup (CSV upload)
- CSV export of results
- SSO / non-password auth
- Match-rate improvements beyond v4
- Roth/Traditional logic
- Rollover guidance integration

If anyone asks for these after using the tool, that's a great signal. Build only what's been requested, not what you imagine will be useful.

## Troubleshooting

**"Matcher logic not yet implemented" error in the deployed app.**
You haven't pasted your v4 logic into `src/matcher.py` yet. Until you do, the app will load, accept input, and then show this error. That's intentional — the scaffold runs end-to-end before you add the substance.

**Streamlit Cloud build fails.**
Check `requirements.txt` matches what your matcher needs. If your v4 logic uses something not in the default list (e.g., `scikit-learn`, `numpy` specific version), add it.

**App is slow on first query.**
Expected. `load_dol_data()` reads and joins your DOL CSVs the first time, then caches in memory. Subsequent queries should be fast.

**Streamlit Cloud sleeps the app after inactivity.**
Free-tier behavior. First load after a sleep takes ~30 seconds. For an internal tool used a few times a week, fine. If usage grows, the paid tier removes the sleep.
