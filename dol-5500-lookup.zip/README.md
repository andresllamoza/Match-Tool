# DOL 5500 Recordkeeper Lookup

A simple internal tool to look up the 401(k) recordkeeper for an employer using Department of Labor Form 5500 filings.

## What it does

Type an employer name (e.g. `Microsoft`, `Walmart`, `Acme Corp`). The tool returns the most likely 401(k) recordkeeper based on the latest available DOL Form 5500 filing data, with a confidence score and near-misses for verification.

## What problem it solves

When a PensionBee user mentions an employer but doesn't know their recordkeeper (provider managing the 401k), Ops or Product teams currently have to: open the DOL Form 5500 data, manually join four datasets, filter Schedule C records for service codes 15 and 64, canonicalize provider names, and match the employer. This takes 5-10 minutes per lookup and requires data familiarity.

This tool collapses that to one text input.

## What it does NOT do

- Identify Roth vs Traditional account splits
- Confirm a user's current employment or termination status
- Confirm the user has an active or funded balance
- Provide rollover guidance (use the Rollover Knowledge Layer for that)
- Provide tax advice

It is a lookup tool, not a decision system.

## Current state

- Match rate: 666/1000 high-confidence matches on the Fortune 1000 reference set (v4 logic)
- Data source: DOL Form 5500 filings, latest available release
- Coverage limitation: welfare-plan filings can occasionally be matched in error; the Schedule C service code filter mitigates but does not fully eliminate this
- Update cadence: DOL releases new 5500 data ~quarterly; current data was loaded [DATE]

## How it's hosted

Streamlit Community Cloud, password-gated, code in a private GitHub repo.

## Productionizing path

If adoption is real, the natural next steps are:

1. Bulk lookup (paste a list of employer names, get a CSV back)
2. Match-rate improvement (the 334 missing matches likely follow patterns)
3. Migration to PensionBee infrastructure with SSO
4. Integration with BeeHive or Intercom workflows

None of these are required for v1.

## Built by

Andres Llamoza, PensionBee US Operations
